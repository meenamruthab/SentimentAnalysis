## A demo to show how we can use ChatGPT to build a Robo-advisor

Codes can be found [here](./ChatGPT_Robo_Advisor_v2.ipynb) and the results can be found [here](./ChatGPT_Robo_Advisor_v2_Results.csv)